package com.list.listapp

import android.support.v7.view.menu.ActionMenuItemView
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView

class ListingAdapter (val names:List<String>):RecyclerView.Adapter<RecyclerView.ViewHolder>(){
    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
      val view=holder as ListingHolder
        view.name.text=names[position]


    }

    override fun getItemCount(): Int {
        //To change body of created functions use File | Settings | File Templates.
        return names.size
    }
override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
    return ListingHolder(LayoutInflater.from(parent.context).inflate(R.layout.list_item,parent,false))
}


private  inner class ListingHolder internal constructor(itemView:View):RecyclerView.ViewHolder(itemView){
    val name =itemView.findViewById<TextView>(R.id.series_names)
}

}